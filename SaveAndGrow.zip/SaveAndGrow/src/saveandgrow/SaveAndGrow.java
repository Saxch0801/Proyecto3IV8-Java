/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package saveandgrow;

import java.util.Scanner;

public class SaveAndGrow {
    public static void main(String[] args) {
        GestorRegistro gestor = new GestorRegistro();
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("\nMenú:");
            System.out.println("1. Registrar Ingreso o Gasto");
            System.out.println("2. Mostrar Ahorros por Mes");
            System.out.println("3. Mostrar Ticket Final");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1 -> gestor.registrarIngresoOGasto(scanner);
                case 2 -> gestor.verAhorrosPorMes();
                case 3 -> gestor.mostrarTicketFinal();
                case 4 -> System.out.println("Saliendo del programa...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 4);
    }
}
