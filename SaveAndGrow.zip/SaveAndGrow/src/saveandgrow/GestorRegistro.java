/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package saveandgrow;

import java.util.ArrayList;
import java.util.Scanner;

public class GestorRegistro {
    private ArrayList<Registro> registros = new ArrayList<>();
    private int contadorID = 1;
    private float totalIngresos = 0;
    private float totalGastos = 0;

    public void registrarIngresoOGasto(Scanner scanner) {
        System.out.print("Ingrese tipo de registro (Ingreso/Gasto): ");
        String tipo;
        while (true) {
            tipo = scanner.nextLine();
            if (tipo.equalsIgnoreCase("Ingreso") || tipo.equalsIgnoreCase("Gasto")) {
                break;
            }
            System.out.print("Tipo invalido. Ingrese 'Ingreso' o 'Gasto': ");
        }

        String tipoGasto = "";
        if (tipo.equalsIgnoreCase("Gasto")) {
            System.out.println("Seleccione tipo de gasto:");
            System.out.println("1. Personal");
            System.out.println("2. Escolar");
            System.out.println("3. Salud");
            int opcionGasto;
            while (true) {
                opcionGasto = scanner.nextInt();
                scanner.nextLine(); // Limpiar buffer
                if (opcionGasto >= 1 && opcionGasto <= 3) {
                    tipoGasto = switch (opcionGasto) {
                        case 1 -> "Personal";
                        case 2 -> "Escolar";
                        case 3 -> "Salud";
                        default -> "";
                    };
                    break;
                }
                System.out.println("Opcion invalida. Seleccione entre 1 y 3.");
            }
        }

        System.out.print("Ingrese monto: ");
        float monto = scanner.nextFloat();
        scanner.nextLine(); // Limpiar buffer

        System.out.print("Ingrese descripcion: ");
        String descripcion = scanner.nextLine();

        System.out.print("Ingrese el mes (1-12): ");
        int mes;
        while (true) {
            mes = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer
            if (mes >= 1 && mes <= 12) {
                break;
            }
            System.out.print("Mes invalido. Ingrese un valor entre 1 y 12: ");
        }

        float ahorro = 0;
        if (tipo.equalsIgnoreCase("Ingreso")) {
            totalIngresos += monto;
        } else {
            totalGastos += monto;
            if (totalGastos <= totalIngresos) {
                ahorro = totalIngresos - totalGastos;
            } else {
                System.out.println("Advertencia: El gasto excede los ingresos disponibles.");
            }
        }

        Registro registro = new Registro(contadorID++, tipo, tipoGasto, monto, descripcion, mes, ahorro);
        registros.add(registro);
        System.out.println("Registro anadido exitosamente.");
    }

    public void listarRegistros() {
        if (registros.isEmpty()) {
            System.out.println("No hay registros para mostrar.");
        } else {
            for (Registro registro : registros) {
                System.out.println(registro);
            }
        }
    }

    public void eliminarRegistro(Scanner scanner) {
        System.out.print("Ingrese el ID del registro a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        if (registros.removeIf(r -> r.getId() == id)) {
            System.out.println("Registro eliminado exitosamente.");
        } else {
            System.out.println("No se encontro un registro con el ID especificado.");
        }
    }

    public void modificarRegistro(Scanner scanner) {
        System.out.print("Ingrese el ID del registro a modificar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        for (Registro registro : registros) {
            if (registro.getId() == id) {
                System.out.print("Ingrese nuevo tipo (Ingreso/Gasto): ");
                String nuevoTipo;
                while (true) {
                    nuevoTipo = scanner.nextLine();
                    if (nuevoTipo.equalsIgnoreCase("Ingreso") || nuevoTipo.equalsIgnoreCase("Gasto")) {
                        break;
                    }
                    System.out.print("Tipo invalido. Ingrese 'Ingreso' o 'Gasto': ");
                }
                registro.setTipo(nuevoTipo);

                if (nuevoTipo.equalsIgnoreCase("Gasto")) {
                    System.out.println("Seleccione nuevo tipo de gasto:");
                    System.out.println("1. Personal");
                    System.out.println("2. Escolar");
                    System.out.println("3. Salud");
                    int opcionGasto;
                    while (true) {
                        opcionGasto = scanner.nextInt();
                        scanner.nextLine(); // Limpiar buffer
                        if (opcionGasto >= 1 && opcionGasto <= 3) {
                            registro.setTipoGasto(switch (opcionGasto) {
                                case 1 -> "Personal";
                                case 2 -> "Escolar";
                                case 3 -> "Salud";
                                default -> "";
                            });
                            break;
                        }
                        System.out.println("Opcion invalida. Seleccione entre 1 y 3.");
                    }
                } else {
                    registro.setTipoGasto("");
                }

                System.out.print("Ingrese nuevo monto: ");
                registro.setMonto(scanner.nextFloat());
                scanner.nextLine(); // Limpiar buffer

                System.out.print("Ingrese nueva descripcion: ");
                registro.setDescripcion(scanner.nextLine());

                System.out.print("Ingrese nuevo mes (1-12): ");
                int nuevoMes;
                while (true) {
                    nuevoMes = scanner.nextInt();
                    scanner.nextLine(); // Limpiar buffer
                    if (nuevoMes >= 1 && nuevoMes <= 12) {
                        break;
                    }
                    System.out.print("Mes invalido. Ingrese un valor entre 1 y 12: ");
                }
                registro.setMes(nuevoMes);

                System.out.println("Registro modificado exitosamente.");
                return;
            }
        }
        System.out.println("Registro con ID especificado no encontrado.");
    }

    public void buscarPorMes(Scanner scanner) {
        System.out.print("Ingrese el mes (1-12) a buscar: ");
        int mes = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        boolean encontrado = false;
        for (Registro registro : registros) {
            if (registro.getMes() == mes) {
                System.out.println(registro);
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron registros para el mes especificado.");
        }
    }

    public void buscarPorID(Scanner scanner) {
        System.out.print("Ingrese el ID del registro a buscar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer

        for (Registro registro : registros) {
            if (registro.getId() == id) {
                System.out.println(registro);
                return;
            }
        }
        System.out.println("Registro con ID especificado no encontrado.");
    }

    public void mostrarTicketFinal() {
        System.out.println("\nTicket final:");
        listarRegistros();
        System.out.println("Total de ingresos: " + totalIngresos);
        System.out.println("Total de gastos: " + totalGastos);
        System.out.println("Ahorro acumulado: " + (totalIngresos - totalGastos));
    }

    public void verAhorrosPorMes() {
        System.out.println("\nAhorros por mes:");
        for (Registro registro : registros) {
            if (registro.getTipo().equalsIgnoreCase("Ingreso") || registro.getAhorro() > 0) {
                System.out.println("Mes: " + registro.getMes() + ", Ahorro: " + registro.getAhorro());
            }
        }
    }
}
