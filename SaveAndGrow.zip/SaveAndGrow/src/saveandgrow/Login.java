/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package saveandgrow;
import java.util.Scanner;

public class Login {
    private final String usuarioValido = "admin";
    private final String contrasenaValida = "1234";

    public boolean iniciarSesion(Scanner scanner) {
        System.out.print("Ingrese usuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Ingrese contrasena: ");
        String contrasena = scanner.nextLine();

        if (usuario.equals(usuarioValido) && contrasena.equals(contrasenaValida)) {
            System.out.println("Inicio de sesion exitoso.");
            return true;
        } else {
            System.out.println("Usuario o contrasena incorrectos.");
            return false;
        }
    }
}
