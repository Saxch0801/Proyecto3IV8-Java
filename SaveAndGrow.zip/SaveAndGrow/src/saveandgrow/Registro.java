package saveandgrow;

public class Registro {
    private int id;
    private String tipo;
    private String tipoGasto;
    private float monto;
    private String descripcion;
    private int mes;
    private float ahorro;

    public Registro(int id, String tipo, String tipoGasto, float monto, String descripcion, int mes, float ahorro) {
        this.id = id;
        this.tipo = tipo;
        this.tipoGasto = tipoGasto;
        this.monto = monto;
        this.descripcion = descripcion;
        this.mes = mes;
        this.ahorro = ahorro;
    }

    public int getId() {
        return id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getTipoGasto() {
        return tipoGasto;
    }

    public void setTipoGasto(String tipoGasto) {
        this.tipoGasto = tipoGasto;
    }

    public float getMonto() {
        return monto;
    }

    public void setMonto(float monto) {
        this.monto = monto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getMes() {
        return mes;
    }

    public void setMes(int mes) {
        this.mes = mes;
    }

    public float getAhorro() {
        return ahorro;
    }

    public void setAhorro(float ahorro) {
        this.ahorro = ahorro;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Tipo: " + tipo + ", Tipo de Gasto: " + tipoGasto + ", Monto: " + monto
                + ", Descripcion: " + descripcion + ", Mes: " + mes + ", Ahorro: " + ahorro;
    }
}
